import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaidcard',
  templateUrl: './prepaidcard.component.html',
  styleUrls: ['./prepaidcard.component.css']
})
export class PrepaidcardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
