import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Dongle3Component } from './dongle3.component';

describe('Dongle3Component', () => {
  let component: Dongle3Component;
  let fixture: ComponentFixture<Dongle3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Dongle3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Dongle3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
