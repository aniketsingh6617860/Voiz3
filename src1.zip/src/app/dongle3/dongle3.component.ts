import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dongle3',
  templateUrl: './dongle3.component.html',
  styleUrls: ['./dongle3.component.css']
})
export class Dongle3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
