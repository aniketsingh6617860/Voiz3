import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewbill',
  templateUrl: './viewbill.component.html',
  styleUrls: ['./viewbill.component.css']
})
export class ViewbillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
