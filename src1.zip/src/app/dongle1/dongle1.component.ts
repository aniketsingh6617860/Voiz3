import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dongle1',
  templateUrl: './dongle1.component.html',
  styleUrls: ['./dongle1.component.css']
})
export class Dongle1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
