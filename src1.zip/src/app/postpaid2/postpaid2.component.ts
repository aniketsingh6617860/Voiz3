import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpaid2',
  templateUrl: './postpaid2.component.html',
  styleUrls: ['./postpaid2.component.css']
})
export class Postpaid2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
