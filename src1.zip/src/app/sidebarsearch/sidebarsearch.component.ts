import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebarsearch',
  templateUrl: './sidebarsearch.component.html',
  styleUrls: ['./sidebarsearch.component.css']
})
export class SidebarsearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
