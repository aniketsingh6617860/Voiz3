import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-postpaid3',
  templateUrl: './postpaid3.component.html',
  styleUrls: ['./postpaid3.component.css']
})
export class Postpaid3Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
