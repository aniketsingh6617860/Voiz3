import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-popupbill',
  templateUrl: './popupbill.component.html',
  styleUrls: ['./popupbill.component.css']
})
export class PopupbillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    
  }

}
