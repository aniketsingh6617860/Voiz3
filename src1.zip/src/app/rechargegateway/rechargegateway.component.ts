import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rechargegateway',
  templateUrl: './rechargegateway.component.html',
  styleUrls: ['./rechargegateway.component.css']
})
export class RechargegatewayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
