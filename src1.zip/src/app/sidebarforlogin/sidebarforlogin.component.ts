import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebarforlogin',
  templateUrl: './sidebarforlogin.component.html',
  styleUrls: ['./sidebarforlogin.component.css']
})
export class SidebarforloginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
