import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Prepaid1Component } from './prepaid1.component';

describe('Prepaid1Component', () => {
  let component: Prepaid1Component;
  let fixture: ComponentFixture<Prepaid1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Prepaid1Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Prepaid1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
