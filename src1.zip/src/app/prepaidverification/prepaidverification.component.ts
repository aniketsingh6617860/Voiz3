import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-prepaidverification',
  templateUrl: './prepaidverification.component.html',
  styleUrls: ['./prepaidverification.component.css']
})
export class PrepaidverificationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
