import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrepaidverificationComponent } from './prepaidverification.component';

describe('PrepaidverificationComponent', () => {
  let component: PrepaidverificationComponent;
  let fixture: ComponentFixture<PrepaidverificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrepaidverificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrepaidverificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
