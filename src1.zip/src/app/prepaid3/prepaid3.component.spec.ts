import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Prepaid3Component } from './prepaid3.component';

describe('Prepaid3Component', () => {
  let component: Prepaid3Component;
  let fixture: ComponentFixture<Prepaid3Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Prepaid3Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Prepaid3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
