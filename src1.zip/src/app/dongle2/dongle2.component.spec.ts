import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Dongle2Component } from './dongle2.component';

describe('Dongle2Component', () => {
  let component: Dongle2Component;
  let fixture: ComponentFixture<Dongle2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Dongle2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Dongle2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
